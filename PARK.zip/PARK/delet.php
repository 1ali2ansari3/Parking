<?php
  
  $db = new PDO ('mysql:host=localhost;dbname=park','root','');
  session_start();
  $login  = $_GET["idPersonne"];
  $ins = $db->prepare("DELETE FROM vehicules WHERE MTr = '$login'"); 
  $ins->execute();
  $ins = $db->prepare("DELETE FROM vidange WHERE MTr = '$login'"); 
  $ins->execute();
  header('location: Liste des vehicules.php');


?>