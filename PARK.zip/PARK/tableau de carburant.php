<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="PARK.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<div class="sidebar">
    <div class="logo-details">
    <i class="large material-icons">account_circle</i>

      <span class="logo_name">Admine</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="Liste des vehicules.PHP"  title="LA LISTE DES VEHICULES">
          <i class="large material-icons">directions_car</i>
            <span class="links_name">Vehicules</span>
          </a>
        </li>
        <li>
          <a href="Ajouter.php" title="Ajouter Vehicule">
          <i class="large material-icons">add_circle</i>
            <span class="links_name">Ajouter Vehicule</span>
          </a>
        </li>
        <li>
          <a href="Suivi DU Carburant.PHP"  title="Les activité de la vehicules pendant l'année">
          <i class="large material-icons">subdirectory_arrow_right</i>
            <span class="links_name">Suivi DU Carburant</span>
          </a>
        </li>
        <li>
          <a href="AJOUTER INFORMATION.PHP" title="Ajouter une Activité">
          <i class="large material-icons">add_circle_outline</i>
            <span class="links_name">Ajouter information</span>
          </a>
        </li>
        <li>
          <a href="Videnge.php">
          <i class="large material-icons " title="Les voitures qui doivent efféctuer un videnge">edit</i>
            <span class="links_name">Videnge</span>
          </a>
        </li>
        <li>
          <a href="CHAUFFEUR.PHP"  title="About-Team">
            <i class='bx bx-user'></i>
            <span class="links_name">Chauffeur</span>
          </a>
        </li>
        <li>
          <a href="tableau de carburant.PHP" class="active" title="About-Team">
            <i class='bx bx-user'></i>
            <span class="links_name">consommation</span>
          </a>
        </li>
        <li>
          <a href="about.PHP" title="About-Team">
            <i class='bx bx-user'></i>
            <span class="links_name">About</span>
          </a>
        </li>
        

        <li class="log_out">
          <a href="PARKING.PHP" title="Log-out" >
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>





  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">PARKING</span>
      </div>
      
      <div class="profile-details">
      <a href="http://www.fste-umi.ac.ma/">

<img src="img/cycle.jpg" style="width:100%" >
</a>
        
        
      </div>
    </nav>

    <div class="home-content">
      

      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="title" style="text-align:center;" >FICHE DE SUIVI DU CARBURANT DE VEHICULE</div>
          
          <?php
  
    $date=date('y');
echo"<div style='font-weight:bolder;display:flex'> 
<div style=' padding:3%;text-align:center; '>
ROYAUME DE MAROC<br>
MINISTRE DE L'INTERIEUR <br>
WILAYA DE LA REGION DRAA-TAFILALET <br>
PROVINCE D'ERRACHIDIA <br>
CONSEIL PROVINCIAL <br>
PARC-AUTO<br>
<hr>
</div>
<div style=' padding:3%;text-align:center;margin-left: 3%;'>
<img src='img/408a565b-8bbd-4cc3-b6b1-f2d1874e2dff.jpg' style='width: 300px;; height: 145px; '>
<hr>
</div>
<div style=' padding:3%;text-align:center;margin-left: 3%;'>
<img src='img/3.jpg' style='width: 300px;; height: 145px; '>
<hr>
</div>
</div>




<div style='background-color:#A9A9A9 ; padding:3%;text-align:center'>
<b>
Tableau de suivi de la consommation de carburant   ".$date."<br>
</b>
</div>

";
    //fiche voiture
    
     echo"</font>";

       //informations de voiture
    $pdo= new PDO("mysql:host=localhost;dbname=park","root","");
    $ins=$pdo->prepare("SELECT * FROM carburant  order by DATE ASC");
    $ins->execute();
    $tab = $ins->fetchAll();
    echo ' <table style="width:100%;text-align:center">
   <tr><th>MTr</th><th>DATE</th>
   <th>DESTINATION</th>
   <th>KM</th>
   <th>N°SUCHE</th>
   <th>PRIX</th>
   <th>UTILISATEUR</th>';
  $s=0;
   
   for($i=0;$i<count($tab);$i++){
    echo"<tr><td>".$tab[$i]['MTr']."<hr></td>";

       echo"<td>".$tab[$i]['DATE']."<hr></td>";
       echo"<td>".$tab[$i]['DESTINATION']."<hr></td>";
       echo"<td>".$tab[$i]['KM']."<hr></td>";
       echo"<td>".$tab[$i]['N°SUCHE']."<hr></td>";
       echo"<td>".$tab[$i]['PRIX']."<hr></td>";
       echo"<td>".$tab[$i]['UTILISATEUR']."<hr></td>";

      $s+=$tab[$i]['PRIX'];
      
       
}
    echo"</table>";    
    echo "<br>";
    
    echo "<div style='background-color:#AAAAAA ; padding:3%;text-align:center'>
    <b>
    total de prix d Année  = ".$s."<br>
    </b>
    </div> ";
?>

</div>
</div>
<script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</html>