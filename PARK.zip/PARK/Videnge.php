<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="PARK.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"  >

     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <style>
html,body {
	height: 100%;
}

body.my-login-page {
	background-color: #f7f9fb;
	font-size: 14px;
}

.my-login-page .brand {
	width: 90px;
	height: 90px;
	overflow: hidden;
	border-radius: 50%;
	margin: 40px auto;
	box-shadow: 0 4px 8px rgba(0,0,0,.05);
	position: relative;
	z-index: 1;
}

.my-login-page .brand img {
	width: 100%;
}

.my-login-page .card-wrapper {
	width: 400px;
}

.my-login-page .card {
	border-color: transparent;
	box-shadow: 0 4px 8px rgba(0,0,0,.05);
}

.my-login-page .card.fat {
	padding: 10px;
}

.my-login-page .card .card-title {
	margin-bottom: 30px;
}

.my-login-page .form-control {
	border-width: 2.3px;
}

.my-login-page .form-group label {
	width: 100%;
}

.my-login-page .btn.btn-block {
	padding: 12px 10px;
}

.my-login-page .footer {
	margin: 40px 0;
	color: #888;
	text-align: center;
}

@media screen and (max-width: 425px) {
	.my-login-page .card-wrapper {
		width: 90%;
		margin: 0 auto;
	}
}

@media screen and (max-width: 320px) {
	.my-login-page .card.fat {
		padding: 0;
	}

	.my-login-page .card.fat .card-body {
		padding: 15px;
	}
}

</style>
   </head>
<body>
<div class="sidebar">
    <div class="logo-details">
    <i class="large material-icons">account_circle</i>

      <span class="logo_name">Admine</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="Liste des vehicules.PHP"  title="LA LISTE DES VEHICULES">
          <i class="large material-icons">directions_car</i>
            <span class="links_name">Vehicules</span>
          </a>
        </li>
        <li>
          <a href="Ajouter.php"  title="Ajouter Vehicule">
          <i class="large material-icons">add_circle</i>
            <span class="links_name">Ajouter Vehicule</span>
          </a>
        </li>
        <li>
          <a href="Suivi DU Carburant.PHP" title="Les activité de la vehicules pendant l'année">
          <i class="large material-icons">subdirectory_arrow_right</i>
            <span class="links_name">Suivi DU Carburant</span>
          </a>
        </li>
        <li>
          <a href="AJOUTER INFORMATION.PHP" title="Ajouter une Activité">
          <i class="large material-icons">add_circle_outline</i>
            <span class="links_name">Ajouter information</span>
          </a>
        </li>
        <li>
          <a href="Videnge.php" class="active">
          <i class="large material-icons " title="Les voitures qui doivent efféctuer un videnge">edit</i>
            <span class="links_name">Videnge</span>
          </a>
        </li>
         <li>
          <a href="CHAUFFEUR.PHP"  title="About-Team">
            <i class='bx bx-user'></i>
            <span class="links_name">Chauffeur</span>
          </a>
        </li>
        <li>
          <a href="tableau de carburant.PHP"title="About-Team">
            <i class='bx bx-user'></i>
            <span class="links_name">consommation</span>
          </a>
        </li>
        <li>
          <a href="about.PHP" title="About-Team">
            <i class='bx bx-user'></i>
            <span class="links_name">About</span>
          </a>
        </li>
       

        <li class="log_out">
          <a href="PARKING.PHP" title="Log-out" >
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>



  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">PARKING</span>
      </div>
      
      <div class="profile-details">
           <a href="http://www.fste-umi.ac.ma/">

               <img src="img/cycle.jpg" style="width:100%" >
           </a>
            </div>
    </nav>

    <div class="home-content">
      

      <div class="sales-boxes">
        <div class="recent-sales box" >
          <div class=""><b>Videnge</b></div><br>
          <font color='gren'><b>NORMAL :</b></font>
          <br>
          <table  cellspacing="28" rowspan="35"  style=" width:100%;
        padding:10px;
        margin: 10px auto;
        background-color: #FFF">
          <tr><th>Matricule</th><th>KILOMETRAGE</th><th>Rest(km)</th><th>éffectuer</th></tr>
    <?php
    $pdo=new PDO("mysql:host=localhost;dbname=park","root",""); 
    $ins = $pdo->prepare("select * from vidange");  
    $ins->execute();
    $tab = $ins->fetchAll(); 
    for ($j = 0; $j <count($tab); $j++){ 
        if($tab[$j]['TYPE']==0 && $tab[$j]['TOTAL']>5900 ){
            $T=6000-$tab[$j]['TOTAL'];

        echo "<tr>
        <td>".$tab[$j]['MTr']."<hr></td>
        <td>".$tab[$j]['TOTAL']."<hr></td>
        <td>".$T."<hr></td>
        <td><a href=\"XX2.php?VV2=".$tab[$j]['MTr']."\"><i class='material-icons'>check_circle</i></a><hr></td>
        </tr>";
        }
    }
    ?>
    </table>
    <br>
    <font color='red'><b>COMPLET :</b></font>
    <br>
    <table  cellspacing="28" rowspan="35"  style=" width:100%;
        padding:10px;
        margin: 10px auto;
        background-color: #FFF">
          <tr><th>Matricule</th><th>KILOMETRAGE</th><th>Rest(km)</th><th>éffectuer</th></tr>
    <?php
    $pdo=new PDO("mysql:host=localhost;dbname=park","root",""); 
    $ins = $pdo->prepare("select * from vidange");  
    $ins->execute();
    $tab = $ins->fetchAll(); 
    for ($j = 0; $j <count($tab); $j++){ 
    if($tab[$j]['TYPE']==1 && $tab[$j]['TOTAL']>5900 ){
        $T=6000-$tab[$j]['TOTAL'];
        echo "<tr>
        <td>".$tab[$j]['MTr']."<hr></td>
        <td>".$tab[$j]['TOTAL']."<hr></td>
        <td>".$T."<hr></td>
        <td><a href=\"X.php?VV=".$tab[$j]['MTr']."\"><i class='material-icons'>check_circle</i></a><hr></td>
        </tr>";
        }
    }
    ?>
    </table>
        </div>
          
        </div>
       
      </div>
    </div>
  </section>

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>